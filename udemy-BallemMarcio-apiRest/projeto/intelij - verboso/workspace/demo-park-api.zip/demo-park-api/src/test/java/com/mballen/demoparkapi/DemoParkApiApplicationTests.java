package com.mballen.demoparkapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoParkApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
